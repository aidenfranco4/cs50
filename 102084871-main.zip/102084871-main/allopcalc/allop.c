#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main(void)
{
    float x = get_float("Enter x value: ");
    float y = get_float("Enter y value: ");
    int ans = get_int("Enter operation number(1 for addition, 2 for subtraction, 3 for multiplication, 4 for division, 5 for exponential equations, 6 for squaring a number, 7 for converting radians to degrees, 8 for converting degrees to radians: ");
    long double pi = 3.14159265358979323846264338327950288419716939937;

    if (ans == 1)
    {
        float z = x + y;
        printf("%f\n", z);
    }
    else if (ans == 2)
    {
        float z = x - y;
        printf("%f\n", z);
    }
    else if (ans == 3)
    {
        float z = x * y;
        printf("%f\n", z);
    }
    else if (ans == 4)
    {
        float z = x / y;
        printf("%f\n", z);
    }
    else if (ans == 5)
    {
        float z = pow(x, y);
        printf("%f\n", z);
    }
    else if (ans == 6)
    {
        char ans1 = get_char("Square x or y? ");
        if (ans1 == 'x' || ans1 == 'X')
        {
            float z = pow(x, 2);
            printf("%f\n", z);
        }
        else if (ans1 == 'y' || ans1 == 'Y')
        {
            float z = pow(y, 2);
            printf("%f\n", z);
        }
    }
    else if (ans == 7)
    {
        float angle = get_float("Enter the angle measure in radians: ");
        float z = ((angle * pi) * 180) / (pi);
        printf("%f\n", z);
    }
    else if (ans == 8)
    {
        float angle_deg = get_float("Enter the angle measure in degrees: ");
        float z = (angle_deg / 180);
        printf("%f\n", z);
    }
}