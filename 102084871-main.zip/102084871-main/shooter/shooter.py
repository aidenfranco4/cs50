import pygame

# initialize the pygame
pygame.init()

# creates the screen
screen = pygame.display.set_mode((800, 600))