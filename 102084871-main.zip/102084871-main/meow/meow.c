#include <cs50.h>
#include <stdio.h>

void meow(int n);

int main()
{
    meow(3);
}

void meow(n)
{
    for (int i = 0; i < n; i++)
        printf("Meow\n");
}
