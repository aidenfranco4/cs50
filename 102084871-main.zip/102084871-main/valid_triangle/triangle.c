#include <stdio.h>
#include <cs50.h>
#include <string.h>

int valid_triangle();

int main(void)
{
    int a = get_int("Enter side 1: \n");
    int b = get_int("Enter side 2: \n");
    int c = get_int("Enter side 3: \n");
    valid_triangle(a, b, c);
}

int valid_triangle(a, b, c)
{
    if (a + b > c)
    {
        printf("TRUE\n");
        return true;
    }
    else
    {
        printf("FALSE\n");
        return false;
    }
}