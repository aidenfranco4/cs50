#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int x = get_int("Enter an x value: ");
    int y = get_int("Enter a y value: ");
    int z = x + y;
    printf("%i\n", z);
}