#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int main(void)
{
    //Prompts user for input
    string line = get_string("Text: ");
    int word_num, sentence_num, letter_num;
    word_num = sentence_num = letter_num = 0;

    //For loop to determine number of letters, words, and sentences
    for (int i = 0, len = strlen(line); i < len; i++)
    {
        if (isalpha(line[i]))
        {
            letter_num++;
        }

        if ((i == 0 && line[i] != ' ') || (i != len - 1 && line[i] == ' ' && line[i + 1] != ' '))
        {

            word_num++;

        }
        if (line[i] == '.' || line[i] == '?' || line[i] == '!')
        {
            sentence_num++;
        }
    }

    //Prerequisites to find index
    float L = (letter_num / (float) word_num) * 100;
    float S = (sentence_num  / (float) word_num) * 100;
    int index = round((0.0588 * L) - (0.296 * S) - 15.8);

    //final output
    if (index < 1)
    {
        printf("Before Grade 1\n");
    }
    else if (index >= 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Grade %i\n", index);
    }
}
